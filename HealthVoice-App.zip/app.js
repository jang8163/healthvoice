// HealthVoice - 음성 기반 건강 & 웰빙 도우미
// Main Application JavaScript

class HealthVoice {
    constructor() {
        this.currentSection = 'dashboard';
        this.isListening = false;
        this.recognition = null;
        this.synthesis = window.speechSynthesis;
        this.medications = JSON.parse(localStorage.getItem('medications')) || [];
        this.healthData = JSON.parse(localStorage.getItem('healthData')) || {
            water: { daily: 0, goal: 8, lastReset: new Date().toDateString() },
            sleep: [],
            bloodPressure: [],
            bloodSugar: [],
            mood: []
        };
        this.exerciseData = JSON.parse(localStorage.getItem('exerciseData')) || [];
        
        this.init();
    }

    init() {
        this.initSpeechRecognition();
        this.initEventListeners();
        this.initTimers();
        this.updateDashboard();
        this.updateCurrentTime();
        this.resetDailyData();
        
        // 페이지 로드 시 인사말
        setTimeout(() => {
            this.speak('안녕하세요! HealthVoice입니다. 건강한 하루를 시작해볼까요?');
        }, 1000);
    }

    // 음성 인식 초기화
    initSpeechRecognition() {
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.recognition = new SpeechRecognition();
            this.recognition.continuous = false;
            this.recognition.interimResults = false;
            this.recognition.lang = 'ko-KR';

            this.recognition.onstart = () => {
                this.isListening = true;
                this.showVoiceModal();
                this.updateVoiceText('듣고 있습니다...');
            };

            this.recognition.onresult = (event) => {
                const transcript = event.results[0][0].transcript;
                this.updateVoiceText(`"${transcript}"`);
                this.processVoiceCommand(transcript);
            };

            this.recognition.onerror = (event) => {
                console.error('음성 인식 오류:', event.error);
                this.hideVoiceModal();
                this.isListening = false;
                this.showToast('음성 인식에 실패했습니다. 다시 시도해주세요.', 'error');
            };

            this.recognition.onend = () => {
                this.isListening = false;
                setTimeout(() => {
                    this.hideVoiceModal();
                }, 2000);
            };
        } else {
            console.warn('이 브라우저는 음성 인식을 지원하지 않습니다.');
        }
    }

    // 이벤트 리스너 초기화
    initEventListeners() {
        // 네비게이션
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const section = e.currentTarget.dataset.section;
                this.showSection(section);
            });
        });

        // 음성 버튼들
        document.getElementById('mainVoiceBtn').addEventListener('click', () => this.startListening());
        document.getElementById('floatingVoiceBtn').addEventListener('click', () => this.startListening());

        // 모달 관련
        document.getElementById('closeVoiceModal').addEventListener('click', () => this.hideVoiceModal());
        document.getElementById('addMedicationBtn').addEventListener('click', () => this.showMedicationModal());
        document.getElementById('closeMedicationModal').addEventListener('click', () => this.hideMedicationModal());
        document.getElementById('cancelMedicationBtn').addEventListener('click', () => this.hideMedicationModal());

        // 복약 관리
        document.getElementById('medicationForm').addEventListener('submit', (e) => this.addMedication(e));
        document.getElementById('medicationFrequency').addEventListener('change', (e) => this.updateTimeInputs(e.target.value));

        // 건강 기록 탭
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tab = e.currentTarget.dataset.tab;
                this.showHealthTab(tab);
            });
        });

        // 건강 기록 버튼들
        document.getElementById('drinkWaterBtn').addEventListener('click', () => this.recordWater());
        document.getElementById('recordSleepBtn').addEventListener('click', () => this.recordSleep());
        document.getElementById('recordBPBtn').addEventListener('click', () => this.recordBloodPressure());
        document.getElementById('recordBSBtn').addEventListener('click', () => this.recordBloodSugar());

        // 기분 기록
        document.querySelectorAll('.mood-option').forEach(btn => {
            btn.addEventListener('click', (e) => {
                document.querySelectorAll('.mood-option').forEach(b => b.classList.remove('selected'));
                e.currentTarget.classList.add('selected');
            });
        });
        document.getElementById('saveMoodBtn').addEventListener('click', () => this.saveMood());

        // 명상
        document.querySelectorAll('.meditation-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const duration = parseInt(e.currentTarget.dataset.duration);
                this.startMeditation(duration);
            });
        });

        // 운동
        document.querySelectorAll('.category-card').forEach(card => {
            card.addEventListener('click', (e) => {
                const category = e.currentTarget.dataset.category;
                this.startExercise(category);
            });
        });

        // 모달 외부 클릭시 닫기
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.classList.remove('active');
                }
            });
        });

        // 응급 버튼
        document.getElementById('emergencyBtn').addEventListener('click', () => this.handleEmergency());
    }

    // 타이머 초기화
    initTimers() {
        // 매 시간마다 물 마시기 알림
        setInterval(() => {
            if (this.shouldRemindWater()) {
                this.speak('물 마실 시간입니다. 수분을 충분히 섭취하세요.');
                this.showToast('💧 물 마실 시간입니다!', 'info');
            }
        }, 3600000); // 1시간

        // 복약 알림 체크 (매 분)
        setInterval(() => {
            this.checkMedicationReminders();
        }, 60000);

        // 시간 업데이트 (매 초)
        setInterval(() => {
            this.updateCurrentTime();
        }, 1000);

        // 장시간 앉아있기 알림 (2시간마다)
        setInterval(() => {
            this.speak('잠시 일어나서 스트레칭을 해보세요. 건강한 자세를 유지하는 것이 중요합니다.');
            this.showToast('🚶‍♂️ 잠시 일어나서 움직여보세요!', 'info');
        }, 7200000); // 2시간
    }

    // 섹션 전환
    showSection(sectionId) {
        // 모든 섹션 숨기기
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });

        // 모든 네비게이션 버튼 비활성화
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.remove('active');
        });

        // 선택된 섹션 표시
        document.getElementById(sectionId).classList.add('active');
        document.querySelector(`[data-section="${sectionId}"]`).classList.add('active');

        this.currentSection = sectionId;

        // 섹션별 초기화
        if (sectionId === 'dashboard') {
            this.updateDashboard();
        } else if (sectionId === 'medication') {
            this.renderMedicationList();
            this.renderMedicationSchedule();
        } else if (sectionId === 'health') {
            this.updateHealthTabs();
        }
    }

    // 음성 인식 시작
    startListening() {
        if (!this.recognition) {
            this.showToast('이 브라우저는 음성 인식을 지원하지 않습니다.', 'error');
            return;
        }

        if (this.isListening) {
            this.recognition.stop();
            return;
        }

        this.recognition.start();
    }

    // 음성 명령 처리
    processVoiceCommand(command) {
        const cmd = command.toLowerCase().trim();
        
        // 복약 관련 명령
        if (cmd.includes('먹었') || cmd.includes('복용')) {
            this.markMedicationTaken();
            this.speak('복약을 확인했습니다. 잘하셨어요!');
            this.showToast('✅ 복약이 기록되었습니다.', 'success');
        }
        // 물 마시기 명령
        else if (cmd.includes('물') && (cmd.includes('마셨') || cmd.includes('마심'))) {
            this.recordWater();
            this.speak('물 마시기를 기록했습니다. 수분 섭취를 꾸준히 해주세요.');
        }
        // 수면 기록 명령
        else if (cmd.includes('잠') || cmd.includes('수면')) {
            const hours = this.extractNumber(cmd);
            if (hours) {
                this.recordSleep(hours);
                this.speak(`${hours}시간 수면을 기록했습니다.`);
            } else {
                this.speak('수면 시간을 알려주세요. 예: 7시간 잤어요');
            }
        }
        // 기분 기록 명령
        else if (cmd.includes('기분') || cmd.includes('좋') || cmd.includes('나쁘') || cmd.includes('스트레스')) {
            let mood = 'neutral';
            if (cmd.includes('좋') || cmd.includes('행복') || cmd.includes('기뻐')) mood = 'happy';
            else if (cmd.includes('나쁘') || cmd.includes('우울') || cmd.includes('슬프')) mood = 'sad';
            else if (cmd.includes('스트레스') || cmd.includes('화나') || cmd.includes('짜증')) mood = 'angry';
            else if (cmd.includes('최고') || cmd.includes('완전') || cmd.includes('매우')) mood = 'very-happy';
            
            this.recordMood(mood, cmd);
            this.speak('기분을 기록했습니다. 오늘도 좋은 하루 되세요.');
        }
        // 운동 명령
        else if (cmd.includes('운동') || cmd.includes('스트레칭') || cmd.includes('체조')) {
            if (cmd.includes('스트레칭')) {
                this.startExercise('stretch');
            } else if (cmd.includes('유산소') || cmd.includes('걷기')) {
                this.startExercise('cardio');
            } else {
                this.startExercise('strength');
            }
            this.speak('운동을 시작하겠습니다. 함께 건강해져요!');
        }
        // 명상 명령
        else if (cmd.includes('명상') || cmd.includes('호흡') || cmd.includes('마음')) {
            this.startMeditation(5);
            this.speak('5분 명상을 시작합니다. 편안한 자세로 앉아주세요.');
        }
        // 혈압 기록 명령
        else if (cmd.includes('혈압')) {
            const numbers = cmd.match(/\d+/g);
            if (numbers && numbers.length >= 2) {
                this.recordBloodPressure(numbers[0], numbers[1]);
                this.speak(`혈압 ${numbers[0]}/${numbers[1]}을 기록했습니다.`);
            } else {
                this.speak('혈압 수치를 알려주세요. 예: 혈압 120 80');
            }
        }
        // 도움말
        else if (cmd.includes('도움') || cmd.includes('명령')) {
            this.showHelp();
        }
        // 기본 응답
        else {
            this.speak('죄송합니다. 명령을 이해하지 못했습니다. 도움말을 원하시면 "도움"이라고 말씀해주세요.');
        }

        // 대시보드 업데이트
        this.updateDashboard();
    }

    // 숫자 추출
    extractNumber(text) {
        const match = text.match(/\d+/);
        return match ? parseInt(match[0]) : null;
    }

    // TTS 음성 출력
    speak(text) {
        if (this.synthesis) {
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = 'ko-KR';
            utterance.rate = 0.9;
            utterance.pitch = 1.0;
            this.synthesis.speak(utterance);
        }
    }

    // 대시보드 업데이트
    updateDashboard() {
        this.updateMedicationProgress();
        this.updateHealthSummary();
        this.updateMoodDisplay();
        this.updateExerciseSummary();
    }

    // 복약 진행상황 업데이트
    updateMedicationProgress() {
        const today = new Date().toDateString();
        const todayMedications = this.getTodayMedications();
        const takenMedications = todayMedications.filter(med => med.taken);
        
        // 진행률 계산
        const total = todayMedications.length;
        const taken = takenMedications.length;
        const percentage = total > 0 ? (taken / total) * 100 : 0;
        
        // 프로그레스 링 업데이트
        const progressCircle = document.querySelector('.progress-ring-circle');
        if (progressCircle) {
            const circumference = 2 * Math.PI * 30; // r=30
            const offset = circumference - (percentage / 100) * circumference;
            progressCircle.style.strokeDashoffset = offset;
            progressCircle.style.stroke = percentage === 100 ? '#48bb78' : '#667eea';
        }
        
        // 텍스트 업데이트
        const progressText = document.querySelector('.progress-text');
        if (progressText) {
            progressText.querySelector('.taken').textContent = taken;
            progressText.querySelector('.total').textContent = total;
        }
        
        // 다음 복약 시간
        const nextMedication = this.getNextMedication();
        const nextMedicationEl = document.querySelector('.next-medication');
        if (nextMedicationEl) {
            nextMedicationEl.textContent = nextMedication ? `다음 복약: ${nextMedication.time}` : '오늘 복약 완료!';
        }
        
        // 오늘의 복약 목록
        const medicationListEl = document.getElementById('todayMedications');
        if (medicationListEl) {
            medicationListEl.innerHTML = todayMedications.map(med => `
                <div class="medication-item ${med.taken ? 'medication-taken' : ''}">
                    <span>${med.name} (${med.time})</span>
                    <span>${med.taken ? '✓' : '○'}</span>
                </div>
            `).join('');
        }
    }

    // 건강 요약 업데이트
    updateHealthSummary() {
        // 물 마시기
        const waterCount = document.getElementById('waterCount');
        if (waterCount) {
            waterCount.textContent = `${this.healthData.water.daily}/${this.healthData.water.goal}잔`;
        }
        
        // 수면
        const sleepHours = document.getElementById('sleepHours');
        if (sleepHours) {
            const lastSleep = this.healthData.sleep[this.healthData.sleep.length - 1];
            sleepHours.textContent = lastSleep ? `${lastSleep.hours}시간` : '-시간';
        }
        
        // 혈압
        const bloodPressure = document.getElementById('bloodPressure');
        if (bloodPressure) {
            const lastBP = this.healthData.bloodPressure[this.healthData.bloodPressure.length - 1];
            bloodPressure.textContent = lastBP ? `${lastBP.systolic}/${lastBP.diastolic}` : '-/-';
        }
    }

    // 기분 표시 업데이트
    updateMoodDisplay() {
        const todayMood = this.getTodayMood();
        const moodDisplay = document.getElementById('todayMood');
        
        if (moodDisplay && todayMood) {
            const moodEmojis = {
                'very-happy': '😄',
                'happy': '😊',
                'neutral': '😐',
                'sad': '😔',
                'angry': '😠'
            };
            
            moodDisplay.innerHTML = `
                <div class="mood-emoji">${moodEmojis[todayMood.mood]}</div>
                <p>${todayMood.note || '좋은 하루 보내세요!'}</p>
            `;
        }
    }

    // 운동 요약 업데이트
    updateExerciseSummary() {
        const exerciseSummary = document.getElementById('exerciseSummary');
        const todayExercise = this.getTodayExercise();
        
        if (exerciseSummary) {
            if (todayExercise.length > 0) {
                const totalMinutes = todayExercise.reduce((sum, ex) => sum + ex.duration, 0);
                exerciseSummary.innerHTML = `
                    <p>오늘 ${totalMinutes}분 운동했습니다! 🎉</p>
                    <button class="btn btn-primary" onclick="healthVoice.startQuickExercise()">
                        <i class="fas fa-play"></i> 추가 운동 시작
                    </button>
                `;
            } else {
                exerciseSummary.innerHTML = `
                    <p>아직 운동을 시작하지 않았습니다.</p>
                    <button class="btn btn-primary" onclick="healthVoice.startQuickExercise()">
                        <i class="fas fa-play"></i> 빠른 운동 시작
                    </button>
                `;
            }
        }
    }

    // 현재 시간 업데이트
    updateCurrentTime() {
        const timeEl = document.querySelector('.current-time');
        if (timeEl) {
            const now = new Date();
            const timeString = now.toLocaleString('ko-KR', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                weekday: 'long',
                hour: '2-digit',
                minute: '2-digit'
            });
            timeEl.textContent = timeString;
        }
    }

    // 일일 데이터 리셋
    resetDailyData() {
        const today = new Date().toDateString();
        
        // 물 마시기 데이터 리셋
        if (this.healthData.water.lastReset !== today) {
            this.healthData.water.daily = 0;
            this.healthData.water.lastReset = today;
            this.saveHealthData();
        }
    }

    // 복약 관련 메서드들
    getTodayMedications() {
        const today = new Date();
        const todayString = today.toDateString();
        
        return this.medications.flatMap(med => 
            med.times.map(time => ({
                id: med.id,
                name: med.name,
                time: time,
                taken: med.takenDates && med.takenDates[todayString] && 
                       med.takenDates[todayString].includes(time)
            }))
        ).sort((a, b) => a.time.localeCompare(b.time));
    }

    getNextMedication() {
        const now = new Date();
        const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
        const todayMedications = this.getTodayMedications();
        
        return todayMedications.find(med => !med.taken && med.time > currentTime);
    }

    markMedicationTaken() {
        const now = new Date();
        const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
        const todayString = now.toDateString();
        
        // 현재 시간에 가장 가까운 미복용 약물 찾기
        const nextMed = this.getTodayMedications().find(med => !med.taken);
        
        if (nextMed) {
            const medication = this.medications.find(med => med.id === nextMed.id);
            if (medication) {
                if (!medication.takenDates) medication.takenDates = {};
                if (!medication.takenDates[todayString]) medication.takenDates[todayString] = [];
                
                medication.takenDates[todayString].push(nextMed.time);
                this.saveMedications();
                this.updateDashboard();
            }
        }
    }

    checkMedicationReminders() {
        const now = new Date();
        const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
        const todayMedications = this.getTodayMedications();
        
        todayMedications.forEach(med => {
            if (!med.taken && med.time === currentTime) {
                this.speak(`${med.name} 복용 시간입니다. 약을 드세요.`);
                this.showToast(`💊 ${med.name} 복용 시간입니다!`, 'warning');
            }
        });
    }

    // 건강 기록 메서드들
    recordWater() {
        this.healthData.water.daily++;
        this.saveHealthData();
        this.updateWaterDisplay();
        this.updateDashboard();
        this.showToast('💧 물 한 잔을 기록했습니다!', 'success');
        
        if (this.healthData.water.daily >= this.healthData.water.goal) {
            this.speak('오늘 수분 섭취 목표를 달성했습니다! 훌륭해요!');
        }
    }

    recordSleep(hours) {
        if (!hours) {
            const sleepInput = document.getElementById('sleepTime');
            hours = parseFloat(sleepInput.value);
            sleepInput.value = '';
        }
        
        if (hours && hours > 0 && hours <= 24) {
            this.healthData.sleep.push({
                date: new Date().toDateString(),
                hours: hours,
                timestamp: Date.now()
            });
            this.saveHealthData();
            this.updateDashboard();
            this.showToast(`😴 ${hours}시간 수면을 기록했습니다!`, 'success');
            
            if (hours < 6) {
                this.speak('수면 시간이 부족합니다. 충분한 휴식을 취하세요.');
            } else if (hours >= 7 && hours <= 9) {
                this.speak('적절한 수면을 취하셨네요. 좋습니다!');
            }
        }
    }

    recordBloodPressure(systolic, diastolic) {
        if (!systolic || !diastolic) {
            systolic = parseInt(document.getElementById('systolic').value);
            diastolic = parseInt(document.getElementById('diastolic').value);
            document.getElementById('systolic').value = '';
            document.getElementById('diastolic').value = '';
        }
        
        if (systolic && diastolic) {
            this.healthData.bloodPressure.push({
                date: new Date().toDateString(),
                systolic: systolic,
                diastolic: diastolic,
                timestamp: Date.now()
            });
            this.saveHealthData();
            this.updateDashboard();
            this.updateVitalsHistory();
            this.showToast(`❤️ 혈압 ${systolic}/${diastolic}을 기록했습니다!`, 'success');
            
            // 혈압 평가
            if (systolic >= 140 || diastolic >= 90) {
                this.speak('혈압이 높습니다. 의사와 상담을 받아보세요.');
            } else if (systolic < 120 && diastolic < 80) {
                this.speak('정상 혈압입니다. 잘 관리하고 계시네요!');
            }
        }
    }

    recordBloodSugar() {
        const bloodSugar = parseInt(document.getElementById('bloodSugar').value);
        document.getElementById('bloodSugar').value = '';
        
        if (bloodSugar) {
            this.healthData.bloodSugar.push({
                date: new Date().toDateString(),
                value: bloodSugar,
                timestamp: Date.now()
            });
            this.saveHealthData();
            this.updateVitalsHistory();
            this.showToast(`🩸 혈당 ${bloodSugar}mg/dL을 기록했습니다!`, 'success');
            
            // 혈당 평가
            if (bloodSugar < 70) {
                this.speak('혈당이 낮습니다. 당분을 섭취하세요.');
            } else if (bloodSugar > 200) {
                this.speak('혈당이 높습니다. 의사와 상담을 받아보세요.');
            } else {
                this.speak('혈당이 정상 범위입니다.');
            }
        }
    }

    // 기분 기록
    saveMood() {
        const selectedMood = document.querySelector('.mood-option.selected');
        const moodNote = document.getElementById('moodNote').value;
        
        if (selectedMood) {
            const mood = selectedMood.dataset.mood;
            this.recordMood(mood, moodNote);
            
            // 초기화
            selectedMood.classList.remove('selected');
            document.getElementById('moodNote').value = '';
            
            this.updateDashboard();
            this.showToast('💝 기분을 기록했습니다!', 'success');
        }
    }

    recordMood(mood, note) {
        const today = new Date().toDateString();
        
        // 오늘 기분이 이미 있으면 업데이트, 없으면 추가
        const existingIndex = this.healthData.mood.findIndex(m => m.date === today);
        const moodData = {
            date: today,
            mood: mood,
            note: note || '',
            timestamp: Date.now()
        };
        
        if (existingIndex >= 0) {
            this.healthData.mood[existingIndex] = moodData;
        } else {
            this.healthData.mood.push(moodData);
        }
        
        this.saveHealthData();
    }

    getTodayMood() {
        const today = new Date().toDateString();
        return this.healthData.mood.find(m => m.date === today);
    }

    // 명상 기능
    startMeditation(duration) {
        this.showSection('mental');
        document.getElementById('meditationSession').style.display = 'block';
        
        let timeLeft = duration * 60; // 분을 초로 변환
        const timerDisplay = document.getElementById('timerDisplay');
        const breathingText = document.querySelector('.breathing-text');
        
        this.meditationTimer = setInterval(() => {
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            
            // 호흡 가이드
            const cycle = timeLeft % 8;
            if (cycle <= 4) {
                breathingText.textContent = '천천히 숨을 들이마시세요...';
            } else {
                breathingText.textContent = '천천히 숨을 내쉬세요...';
            }
            
            timeLeft--;
            
            if (timeLeft < 0) {
                clearInterval(this.meditationTimer);
                this.endMeditation();
            }
        }, 1000);
        
        // 명상 시작 안내
        this.speak(`${duration}분 명상을 시작합니다. 편안한 자세로 앉아서 호흡에 집중해주세요.`);
        
        // 명상 제어 버튼
        document.getElementById('stopMeditationBtn').onclick = () => this.endMeditation();
        document.getElementById('pauseMeditationBtn').onclick = () => this.pauseMeditation();
    }

    endMeditation() {
        clearInterval(this.meditationTimer);
        document.getElementById('meditationSession').style.display = 'none';
        this.speak('명상이 끝났습니다. 마음이 편안해지셨나요? 좋은 시간이었습니다.');
        this.showToast('🧘‍♀️ 명상을 완료했습니다!', 'success');
    }

    // 운동 기능
    startExercise(category) {
        this.showSection('exercise');
        
        const exercises = {
            stretch: [
                { name: '목 스트레칭', description: '목을 좌우로 천천히 돌려주세요', duration: 30 },
                { name: '어깨 스트레칭', description: '어깨를 위아래로 움직여주세요', duration: 30 },
                { name: '허리 스트레칭', description: '허리를 좌우로 비틀어주세요', duration: 30 }
            ],
            cardio: [
                { name: '제자리 걷기', description: '제자리에서 천천히 걸어주세요', duration: 60 },
                { name: '팔 벌려 뛰기', description: '가볍게 점프하며 팔을 벌려주세요', duration: 30 },
                { name: '무릎 올리기', description: '무릎을 가슴 높이까지 올려주세요', duration: 30 }
            ],
            strength: [
                { name: '스쿼트', description: '다리를 어깨너비로 벌리고 앉았다 일어서세요', duration: 30, reps: true },
                { name: '벽 팔굽혀펴기', description: '벽에 손을 대고 팔굽혀펴기를 해주세요', duration: 30, reps: true },
                { name: '플랭크', description: '엎드려서 팔과 발끝으로 몸을 지탱해주세요', duration: 30 }
            ]
        };
        
        this.currentExercise = exercises[category];
        this.currentExerciseIndex = 0;
        this.startCurrentExercise();
    }

    startCurrentExercise() {
        if (this.currentExerciseIndex >= this.currentExercise.length) {
            this.endExercise();
            return;
        }
        
        const exercise = this.currentExercise[this.currentExerciseIndex];
        document.getElementById('exerciseSession').style.display = 'block';
        document.getElementById('exerciseName').textContent = exercise.name;
        document.getElementById('exerciseDescription').textContent = exercise.description;
        
        let timeLeft = exercise.duration;
        let reps = 0;
        
        const timerEl = document.getElementById('exerciseTimer');
        const repEl = document.getElementById('repCounter');
        
        this.speak(`${exercise.name}을 시작합니다. ${exercise.description}`);
        
        this.exerciseTimer = setInterval(() => {
            timerEl.textContent = `00:${timeLeft.toString().padStart(2, '0')}`;
            
            if (exercise.reps) {
                reps++;
                repEl.textContent = `${reps} 회`;
                this.speak(reps.toString());
            }
            
            timeLeft--;
            
            if (timeLeft < 0) {
                clearInterval(this.exerciseTimer);
                this.speak('운동 완료! 잘하셨습니다!');
                this.currentExerciseIndex++;
                setTimeout(() => this.startCurrentExercise(), 3000);
            }
        }, 1000);
        
        // 운동 제어 버튼
        document.getElementById('nextExerciseBtn').onclick = () => {
            clearInterval(this.exerciseTimer);
            this.currentExerciseIndex++;
            this.startCurrentExercise();
        };
        
        document.getElementById('stopExerciseBtn').onclick = () => this.endExercise();
    }

    endExercise() {
        clearInterval(this.exerciseTimer);
        document.getElementById('exerciseSession').style.display = 'none';
        
        // 운동 기록 저장
        const duration = this.currentExercise.reduce((sum, ex) => sum + ex.duration, 0) / 60;
        this.exerciseData.push({
            date: new Date().toDateString(),
            duration: Math.round(duration),
            type: this.currentExercise[0].name.includes('스트레칭') ? 'stretch' : 
                  this.currentExercise[0].name.includes('걷기') ? 'cardio' : 'strength',
            timestamp: Date.now()
        });
        
        this.saveExerciseData();
        this.updateDashboard();
        this.speak('운동을 완료했습니다! 정말 잘하셨어요! 꾸준히 운동하는 것이 건강의 비결입니다.');
        this.showToast('💪 운동을 완료했습니다!', 'success');
    }

    startQuickExercise() {
        this.startExercise('stretch');
    }

    getTodayExercise() {
        const today = new Date().toDateString();
        return this.exerciseData.filter(ex => ex.date === today);
    }

    // UI 업데이트 메서드들
    updateWaterDisplay() {
        const waterLevel = document.getElementById('waterLevel');
        const waterAmount = document.getElementById('waterAmount');
        
        if (waterLevel && waterAmount) {
            const percentage = (this.healthData.water.daily / this.healthData.water.goal) * 100;
            waterLevel.style.height = Math.min(percentage, 100) + '%';
            
            const mlPerGlass = 250;
            const currentMl = this.healthData.water.daily * mlPerGlass;
            const goalMl = this.healthData.water.goal * mlPerGlass;
            waterAmount.textContent = `${currentMl}ml / ${goalMl}ml`;
        }
    }

    updateVitalsHistory() {
        const historyEl = document.getElementById('vitalsHistory');
        if (!historyEl) return;
        
        const recentBP = this.healthData.bloodPressure.slice(-5).reverse();
        const recentBS = this.healthData.bloodSugar.slice(-5).reverse();
        
        historyEl.innerHTML = `
            <h4>최근 혈압 기록</h4>
            ${recentBP.map(bp => `
                <div class="vital-record">
                    <span>${new Date(bp.timestamp).toLocaleDateString()}</span>
                    <span>${bp.systolic}/${bp.diastolic} mmHg</span>
                </div>
            `).join('')}
            
            <h4>최근 혈당 기록</h4>
            ${recentBS.map(bs => `
                <div class="vital-record">
                    <span>${new Date(bs.timestamp).toLocaleDateString()}</span>
                    <span>${bs.value} mg/dL</span>
                </div>
            `).join('')}
        `;
    }

    // 탭 관련 메서드들
    showHealthTab(tabName) {
        // 모든 탭 버튼 비활성화
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
        
        // 선택된 탭 활성화
        document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
        document.getElementById(`${tabName}-tab`).classList.add('active');
        
        // 탭별 초기화
        if (tabName === 'water') {
            this.updateWaterDisplay();
        } else if (tabName === 'vitals') {
            this.updateVitalsHistory();
        }
    }

    updateHealthTabs() {
        this.updateWaterDisplay();
        this.updateVitalsHistory();
    }

    // 모달 관련 메서드들
    showVoiceModal() {
        document.getElementById('voiceModal').classList.add('active');
    }

    hideVoiceModal() {
        document.getElementById('voiceModal').classList.remove('active');
    }

    updateVoiceText(text) {
        document.getElementById('voiceText').textContent = text;
    }

    showMedicationModal() {
        document.getElementById('medicationModal').classList.add('active');
        this.updateTimeInputs(1); // 기본값: 하루 1회
    }

    hideMedicationModal() {
        document.getElementById('medicationModal').classList.remove('active');
        document.getElementById('medicationForm').reset();
    }

    updateTimeInputs(frequency) {
        const timesContainer = document.getElementById('medicationTimes');
        timesContainer.innerHTML = '';
        
        const defaultTimes = {
            1: ['09:00'],
            2: ['09:00', '21:00'],
            3: ['08:00', '13:00', '19:00']
        };
        
        const times = defaultTimes[frequency] || ['09:00'];
        
        times.forEach((time, index) => {
            const timeInput = document.createElement('div');
            timeInput.className = 'time-input';
            timeInput.innerHTML = `
                <input type="time" value="${time}" required>
                ${times.length > 1 ? `<button type="button" onclick="this.parentElement.remove()">삭제</button>` : ''}
            `;
            timesContainer.appendChild(timeInput);
        });
    }

    addMedication(e) {
        e.preventDefault();
        
        const name = document.getElementById('medicationName').value;
        const dosage = document.getElementById('medicationDosage').value;
        const frequency = document.getElementById('medicationFrequency').value;
        const times = Array.from(document.querySelectorAll('#medicationTimes input[type="time"]'))
                          .map(input => input.value)
                          .filter(time => time);
        
        if (name && times.length > 0) {
            const medication = {
                id: Date.now(),
                name: name,
                dosage: dosage,
                frequency: parseInt(frequency),
                times: times,
                takenDates: {}
            };
            
            this.medications.push(medication);
            this.saveMedications();
            this.hideMedicationModal();
            this.updateDashboard();
            this.renderMedicationList();
            this.showToast('💊 약물이 추가되었습니다!', 'success');
            this.speak(`${name} 약물이 추가되었습니다. 복약 시간을 잊지 마세요.`);
        }
    }

    renderMedicationList() {
        const listEl = document.getElementById('medicationList');
        if (!listEl) return;
        
        listEl.innerHTML = this.medications.map(med => `
            <div class="medication-card">
                <h4>${med.name}</h4>
                <div class="medication-details">
                    복용량: ${med.dosage} | 하루 ${med.frequency}회
                </div>
                <div class="medication-times">
                    ${med.times.map(time => `<span class="time-badge">${time}</span>`).join('')}
                </div>
                <button class="btn btn-danger btn-sm" onclick="healthVoice.removeMedication(${med.id})">
                    <i class="fas fa-trash"></i> 삭제
                </button>
            </div>
        `).join('');
    }

    renderMedicationSchedule() {
        const scheduleEl = document.getElementById('medicationSchedule');
        if (!scheduleEl) return;
        
        const todayMedications = this.getTodayMedications();
        
        scheduleEl.innerHTML = todayMedications.map(med => `
            <div class="timeline-item ${med.taken ? 'completed' : ''}">
                <div class="timeline-time">${med.time}</div>
                <div class="timeline-medication">${med.name}</div>
            </div>
        `).join('');
    }

    removeMedication(id) {
        if (confirm('이 약물을 삭제하시겠습니까?')) {
            this.medications = this.medications.filter(med => med.id !== id);
            this.saveMedications();
            this.renderMedicationList();
            this.updateDashboard();
            this.showToast('약물이 삭제되었습니다.', 'info');
        }
    }

    // 유틸리티 메서드들
    shouldRemindWater() {
        const now = new Date();
        const hour = now.getHours();
        return hour >= 8 && hour <= 22 && this.healthData.water.daily < this.healthData.water.goal;
    }

    showHelp() {
        const helpText = `
        사용 가능한 음성 명령:
        • "약 먹었어요" - 복약 기록
        • "물 마셨어요" - 물 마시기 기록
        • "7시간 잤어요" - 수면 기록
        • "기분 좋아요" - 기분 기록
        • "운동 시작" - 운동 시작
        • "명상" - 명상 시작
        • "혈압 120 80" - 혈압 기록
        `;
        
        this.speak(helpText.replace(/[•\n]/g, ' '));
        this.showToast('음성 명령 도움말을 들려드렸습니다.', 'info');
    }

    handleEmergency() {
        this.speak('응급 상황입니다. 119에 연락하거나 가까운 응급실로 가세요.');
        this.showToast('🚨 응급 상황 - 119에 연락하세요!', 'error');
        
        // 응급 연락처 표시
        if (confirm('119에 전화를 거시겠습니까?')) {
            window.open('tel:119');
        }
    }

    showToast(message, type = 'success') {
        const toast = document.getElementById('toast');
        const icon = toast.querySelector('.toast-icon');
        const messageEl = toast.querySelector('.toast-message');
        
        // 아이콘 설정
        const icons = {
            success: 'fas fa-check-circle',
            error: 'fas fa-exclamation-circle',
            warning: 'fas fa-exclamation-triangle',
            info: 'fas fa-info-circle'
        };
        
        icon.className = `toast-icon ${icons[type]}`;
        messageEl.textContent = message;
        toast.className = `toast ${type}`;
        
        // 토스트 표시
        toast.classList.add('show');
        
        // 3초 후 숨기기
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }

    // 데이터 저장/로드 메서드들
    saveMedications() {
        localStorage.setItem('medications', JSON.stringify(this.medications));
    }

    saveHealthData() {
        localStorage.setItem('healthData', JSON.stringify(this.healthData));
    }

    saveExerciseData() {
        localStorage.setItem('exerciseData', JSON.stringify(this.exerciseData));
    }
}

// 앱 초기화
let healthVoice;
document.addEventListener('DOMContentLoaded', () => {
    healthVoice = new HealthVoice();
});

// 전역 함수들 (HTML에서 직접 호출)
function startQuickExercise() {
    healthVoice.startQuickExercise();
}
